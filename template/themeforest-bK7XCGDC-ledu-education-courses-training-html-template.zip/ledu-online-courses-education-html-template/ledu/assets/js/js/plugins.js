//  Bootstrap Bundle Min Js
document.writeln('<script src="assets/js/bootstrap.bundle.min.js" type="text/javascript"></script>');

// Meanmenu Min Js
document.writeln('<script src="assets/js/meanmenu.min.js" type="text/javascript"></script>');

// Ajaxchimp Min Js
document.writeln('<script src="assets/js/ajaxchimp.min.js" type="text/javascript"></script>');

// Form Validator Min Js
document.writeln('<script src="assets/js/form-validator.min.js" type="text/javascript"></script>');

// Contact Form  Js
document.writeln('<script src="assets/js/contact-form-script.js" type="text/javascript"></script>');

// Owl Carousel  Js
document.writeln('<script src="assets/js/owl.carousel.min.js" type="text/javascript"></script>');

// Magnific Popup  Js
document.writeln('<script src="assets/js/magnific-popup.min.js" type="text/javascript"></script>');

// AOS  Js
document.writeln('<script src="assets/js/aos.js" type="text/javascript"></script>');

// Odometer JS
document.writeln('<script src="assets/js/odometer.min.js" type="text/javascript"></script>');
document.writeln('<script src="assets/js/appear.min.js" type="text/javascript"></script>');

// TweenMax min JS
document.writeln('<script src="assets/js/tweenMax.min.js" type="text/javascript"></script>');